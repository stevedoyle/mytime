__version__ = "0.8.2"

# Tool-specific versions
MYTIME_VERSION = "0.8.0"
MYDAY_VERSION = "0.2.0"
