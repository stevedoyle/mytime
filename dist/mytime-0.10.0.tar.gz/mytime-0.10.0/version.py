__version__ = "0.10.0"

# Tool-specific versions
MYTIME_VERSION = "0.8.0"
MYDAY_VERSION = "0.4.0"
