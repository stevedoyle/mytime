Some other file without time info. Will be ignored by mytime.
